package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.widget.TextWatcher;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity;

    private Context context;

        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    setContextView(R.layout.activity_main);
    TextView username = (TextView) findViewbyId(R.id.username);
    TextView password = (TextView) findViewbyID(R.id.password);
    MATERIALBUTTON LOGINBTN = (MaterialButton) findViewById(R.id.loginbtn);
    loginbtn.setOnClickListener(new Viet.OnClickListener()
    {
        @Override
        public void onClick (View v) {
            if(username.getText().toString().equals("admin") && password.getText().toString().equals("admin")){
                Toast.makeText(context:MainActivity.this.text:"Login Successful!", Toast.LENGTH_SHORT).show();
            }
            else
                Toast.makeText(context::MainActivity.this.text:"Login Unsuccessful", Toast.LENGTH_SHORT).show();
        }
    });